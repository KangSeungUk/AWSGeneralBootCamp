<form name="input" action="rds-write-config.php" method="post">
<table>
<tr><td>Endpoint:</td><td><input type="text" name="endpoint" size=50 /></td></tr>
<tr><td>Database:</td><td><input type="text" name="database" size=20 /></td></tr>
<tr><td>Username:</td><td><input type="text" name="username" size=20 /></td></tr>
<tr><td>Password:</td><td><input type="password" name="password" size=20 /></td></tr>
<tr><td colspan=2><input type="submit" value="Submit" /></td></tr>
</table>
</form>
